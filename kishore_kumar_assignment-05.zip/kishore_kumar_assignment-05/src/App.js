import Gallery from './components/Gallery';
function App() {

  
  return (
    <div className="App">
    <Gallery/>
    </div>
  );
}

export default App;
